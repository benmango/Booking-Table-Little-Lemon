import React from 'react'

export const OrderOnline = () => {
  return (
    <div>OrderOnline</div>
  )
}