export { Reservations } from "./Reservations";

export { About } from "./About";
export { HomePage } from "./HomePage";
export { Menu } from "./Menu";
export { OrderOnline} from "./OrderOnline"
export { Login} from "./Login"